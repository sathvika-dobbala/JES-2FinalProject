import sqlite3

def fetch_all_data():
    # Connect to the SQLite database
    conn = sqlite3.connect('app.db')  # Make sure to provide the correct path to your database
    cursor = conn.cursor()

    # Query to retrieve all table names from the database
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
    tables = cursor.fetchall()

    # Print out all tables and their corresponding data
    for table in tables:
        table_name = table[0]
        print(f"Data from table: {table_name}")
        
        # Query to fetch all data from the table
        cursor.execute(f"SELECT * FROM {table_name}")
        rows = cursor.fetchall()

        # Print the column names
        column_names = [description[0] for description in cursor.description]
        print("Columns:", column_names)

        # Print each row of data
        for row in rows:
            print(row)
        print('-' * 50)  # Separator between tables

    # Close the connection
    conn.close()

if __name__ == "__main__":
    fetch_all_data()
