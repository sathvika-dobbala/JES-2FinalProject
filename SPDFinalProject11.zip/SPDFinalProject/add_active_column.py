import sqlite3

# Function to get a connection to your database
def get_db_connection():
    # Change the path to your database if necessary
    return sqlite3.connect('app.db')

# Function to add the 'active' column to the 'reservations' table
def add_active_column():
    conn = get_db_connection()
    cursor = conn.cursor()

    # SQL query to add the 'active' column
    alter_query = 'ALTER TABLE reservations ADD COLUMN active BOOLEAN DEFAULT 1;'

    try:
        cursor.execute(alter_query)
        conn.commit()
        print("Column 'active' added successfully.")
    except sqlite3.OperationalError as e:
        print(f"Error occurred: {e}")
    finally:
        conn.close()

# Run the function to add the column
if __name__ == '__main__':
    add_active_column()
