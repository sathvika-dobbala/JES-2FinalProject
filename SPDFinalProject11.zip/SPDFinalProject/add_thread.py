import sqlite3

def update_db():
    conn = sqlite3.connect('app.db')
    c = conn.cursor()

    # Check if the thread_id column already exists, if not, add it
    c.execute('''
        ALTER TABLE messages ADD COLUMN thread_id INTEGER
    ''')

    conn.commit()
    conn.close()

# Run the update_db function once to modify the table
update_db()
