from flask import Flask, render_template, request, redirect, url_for, session, flash, send_file
import io
import sqlite3
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
from werkzeug.utils import secure_filename

timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your_secret_key'


def get_db_connection():
    conn = sqlite3.connect('app.db')
    conn.row_factory = sqlite3.Row
    return conn

from werkzeug.utils import secure_filename
import os

DATABASE = 'app.db'

# Function to update resource in the database
def update_resource_in_db(resource_id, title, description, category, availability):
    conn = get_db_connection()
    conn.execute('''UPDATE resources 
                    SET title = ?, description = ?, category = ?, availability = ? 
                    WHERE id = ?''', 
                 (title, description, category, availability, resource_id))
    conn.commit()
    conn.close()


def get_db():
    """Connect to the database"""
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row  # This allows us to access columns by name
    return conn

# Function to get resource by ID
def get_resource_by_id(resource_id):
    conn = get_db_connection()
    # Use 'id' instead of 'resource_id' to match the column name
    resource = conn.execute('SELECT * FROM resources WHERE id = ?', (resource_id,)).fetchone()
    conn.close()
    return resource



# Create tables if they don't exist
def init_db():
    with get_db_connection() as conn:
        # Create users table
        conn.execute('''CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY,
            name TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE,
            password TEXT NOT NULL
        )''')
        
        # Create resources table
        conn.execute('''CREATE TABLE IF NOT EXISTS resources (
            id INTEGER PRIMARY KEY,
            title TEXT NOT NULL,
            description TEXT NOT NULL,
            available_date_time TEXT NOT NULL,
            user_id INTEGER,
            FOREIGN KEY (user_id) REFERENCES users (id)
        )''')
        
        # Insert sample data for testing (John Doe)
        conn.execute('''INSERT OR IGNORE INTO users (name, email, password) 
                        VALUES (?, ?, ?)''', 
                        ('John Doe', 'johndoe@example.com', generate_password_hash('johnpassword123')))
        conn.commit()

        print("Database initialized with users and resources tables.")

def update_reviews_table():
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        print("Starting reviews table update...")
        
        # Backup existing reviews
        cursor.execute("CREATE TABLE IF NOT EXISTS reviews_backup AS SELECT * FROM reviews")
        print("Created backup table")
        
        # Drop the existing reviews table
        cursor.execute("DROP TABLE IF EXISTS reviews")
        print("Dropped old reviews table")
        
        # Create new reviews table with resource_id
        cursor.execute('''
            CREATE TABLE reviews (
                review_id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                reviewer_id INTEGER NOT NULL,
                resource_id INTEGER NOT NULL,
                rating INTEGER NOT NULL,
                comment TEXT NOT NULL,
                timestamp TEXT NOT NULL,
                FOREIGN KEY(user_id) REFERENCES users(user_id),
                FOREIGN KEY(reviewer_id) REFERENCES users(user_id),
                FOREIGN KEY(resource_id) REFERENCES resources(resource_id)
            )
        ''')
        print("Created new reviews table with updated schema")
        
        conn.commit()
        print("Reviews table updated successfully!")
        
    except sqlite3.Error as e:
        print(f"Database error: {e}")
        conn.rollback()
    finally:
        conn.close()

# First page (set as the home page)
@app.route('/')
def first_page():
    if 'user_id' in session:
        return redirect(url_for('home'))  # If logged in, redirect to home page
    return render_template('firstpage.html')  # Render firstpage.html if not logged in

# Home page
@app.route('/home')
def home():
    if 'user_id' not in session:
        return redirect(url_for('first_page'))  # Redirect to first page if not logged in
    return render_template('home.html')

# Login page (this is for user authentication)
@app.route('/log_in_page', methods=['GET', 'POST'])
def log_in_page():
    if 'user_id' in session:
        return redirect(url_for('home'))  # Redirect to home if already logged in
    
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        
        conn = get_db_connection()
        # Make sure you are selecting the correct columns.
        user = conn.execute('SELECT * FROM users WHERE email = ?', (email,)).fetchone()
        conn.close()
        
        if user:
            # Check password if user is found
            if check_password_hash(user['password'], password):  # Verify hashed password
                session['user_id'] = user['user_id']  # Use correct column name
                session['user_name'] = user['name']
                flash("Login successful!", "success")
                return redirect(url_for('home'))  # Redirect to home page after login
            else:
                flash("Invalid email or password.", "danger")  # Invalid login feedback
        else:
            flash("No user found with that email address.", "danger")

    return render_template('log_in_page.html')  # This will render the actual login page

# Registration page (for new users)
@app.route('/register', methods=['GET', 'POST'])
def register():
    if 'user_id' in session:
        return redirect(url_for('home'))  # Redirect to home if already logged in
    
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        password = generate_password_hash(request.form['password'])  # Hash the password
        
        conn = get_db_connection()
        conn.execute('INSERT INTO users (name, email, password) VALUES (?, ?, ?)', (name, email, password))
        conn.commit()
        conn.close()
        
        flash("Registration successful! Please log in.", "success")
        return redirect(url_for('log_in_page'))  # After registering, redirect to the login page
    
    return render_template('register.html')

# Dashboard page (users' personal space, where resources can be managed)
@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect(url_for('first_page'))  # Redirect to first page if not logged in
    
    conn = get_db_connection()
    resources = conn.execute('SELECT * FROM resources WHERE user_id = ?', (session['user_id'],)).fetchall()
    conn.close()
    
    return render_template('dashboard.html', resources=resources)

# Add resource page (for adding new resources)
@app.route('/add_resource', methods=['GET', 'POST'])
def add_resource():
    if 'user_id' not in session:
        return redirect(url_for('first_page'))  # Redirect to first page if not logged in
    
    if request.method == 'POST':
        title = request.form['title']
        description = request.form['description']
        user_id = session.get('user_id')

        image_name = request.form['image_name']

        # If the image name doesn't already have a .jpg extension, add it
        if not image_name.lower().endswith('.jpg'):
            image_name = f"{image_name}.jpg"  # Append .jpg to the image name

        # Save the image path relative to /images/ (no /static/)
        image_path = f"images/{image_name}"

        # Insert into the database
        conn = get_db_connection()
        conn.execute('INSERT INTO resources (title, description, user_id, images) VALUES (?, ?, ?, ?)', 
             (title, description, user_id, image_path))
        conn.commit()
        conn.close()

        flash("Resource added successfully!", "success")
        return redirect(url_for('dashboard'))
    
    return render_template('add_resource.html')



# Route for Spaces page
@app.route('/spaces')
def spaces():
    return render_template('spaces.html')

@app.route('/rent_resources')
def rent_resources():
    conn = get_db_connection()
    try:
        # Fetch all available resources with all columns
        resources = conn.execute('''
            SELECT 
                resource_id,
                title,
                description,
                category,
                availability,
                date_posted,
                image,
                image_type
            FROM resources 
            WHERE availability = "available"
            ORDER BY date_posted DESC
        ''').fetchall()
        
        return render_template('rent_resources.html', resources=resources)
    
    except sqlite3.Error as e:
        print(f"Database error: {e}")
        flash("Error loading resources", "error")
        return render_template('rent_resources.html', resources=[])
    
    finally:
        conn.close()

@app.route('/lease_resources', methods=['GET', 'POST'])
def lease_resources():
    if 'user_id' not in session:
        return redirect(url_for('first_page'))

    if request.method == 'POST':
        try:
            # Get form data
            title = request.form['title']
            description = request.form['description']
            category = request.form['category']
            date_posted = datetime.now().strftime('%Y-%m-%d')
            
            # Handle image upload
            resource_image = request.files['resource_image']
            image_data = resource_image.read() if resource_image else None
            image_type = resource_image.content_type if resource_image else None

            conn = get_db_connection()
            
            # First, let's check if the resources table exists with the correct schema
            conn.execute('''CREATE TABLE IF NOT EXISTS resources (
                resource_id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                title TEXT NOT NULL,
                description TEXT,
                image BLOB,
                image_type TEXT,
                category TEXT,
                availability TEXT DEFAULT 'available',
                date_posted TEXT NOT NULL,
                FOREIGN KEY(user_id) REFERENCES users(user_id)
            )''')

            # Insert the new resource
            conn.execute('''
                INSERT INTO resources (
                    user_id, title, description, category, 
                    image, image_type, availability, date_posted
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                session['user_id'],
                title,
                description,
                category,
                image_data,
                image_type,
                'available',
                date_posted
            ))
            
            conn.commit()
            flash("Resource added successfully!", "success")
            return redirect(url_for('resources'))

        except sqlite3.Error as e:
            print(f"Database error: {e}")
            flash("Error adding resource", "error")
            return render_template('lease_resources.html')
        
        except Exception as e:
            print(f"Error: {e}")
            flash("An error occurred while adding the resource", "error")
            return render_template('lease_resources.html')
        
        finally:
            if 'conn' in locals():
                conn.close()

    # GET request - just display the form
    return render_template('lease_resources.html', today_date=datetime.now().strftime('%Y-%m-%d'))

# Route to serve user profile images
@app.route('/user_image/<int:user_id>')
def user_image(user_id):
    conn = get_db_connection()
    user = conn.execute('SELECT profile_image, profile_image_type FROM users WHERE user_id = ?', 
                       (user_id,)).fetchone()
    conn.close()

    if user and user['profile_image']:
        return send_file(
            io.BytesIO(user['profile_image']),
            mimetype=user['profile_image_type']
        )
    return redirect(url_for('static', filename='default_profile.jpg'))

# Route to serve resource images
@app.route('/resource_image/<int:resource_id>')
def resource_image(resource_id):
    conn = get_db_connection()
    resource = conn.execute('SELECT image, image_type FROM resources WHERE resource_id = ?', 
                          (resource_id,)).fetchone()
    conn.close()

    if resource and resource['image']:
        return send_file(
            io.BytesIO(resource['image']),
            mimetype=resource['image_type']
        )
    return redirect(url_for('static', filename='default_resource.jpg'))

# Route for Resources page
@app.route('/resources')
def resources():
    conn = get_db_connection()  # Use the connection function that sets row_factory
    try:
        # Just fetch all resources without trying to access specific columns
        resources = conn.execute('''
            SELECT * FROM resources 
            ORDER BY date_posted DESC
        ''').fetchall()
        
        return render_template('resources.html', resources=resources)
    
    except sqlite3.Error as e:
        print(f"Database error: {e}")
        flash("Error loading resources", "error")
        return render_template('resources.html', resources=[])
    
    finally:
        conn.close()


# Route for Profile page
@app.route('/profile')
def profile():
    if 'user_id' not in session:
        return redirect(url_for('log_in_page'))

    conn = get_db_connection()
    try:
        # Fetch user details
        user = conn.execute('''
            SELECT user_id, name, email, profile_image, profile_image_type, location
            FROM users 
            WHERE user_id = ?
        ''', (session['user_id'],)).fetchone()

        if not user:
            return redirect(url_for('log_in_page'))

        # Updated query to fetch reserved resources with image data
        reserved_resources = conn.execute('''
            SELECT 
                r.reservation_id,
                r.start_date,
                r.end_date,
                r.active,
                res.resource_id,
                res.title,
                res.description,
                res.category,
                res.availability,
                res.image,
                res.image_type
            FROM reservations r
            JOIN resources res ON r.resource_id = res.resource_id
            WHERE r.user_id = ? AND r.active = 1
        ''', (session['user_id'],)).fetchall()

        # Updated query to fetch all user's resources with image data
        all_resources = conn.execute('''
            SELECT 
                resource_id,
                title,
                description,
                category,
                availability,
                image,
                image_type,
                date_posted
            FROM resources 
            WHERE user_id = ?
        ''', (session['user_id'],)).fetchall()

        return render_template('profile.html',
                             user=user,
                             reserved_resources=reserved_resources,
                             all_resources=all_resources)

    except sqlite3.Error as e:
        print(f"Database error: {e}")
        flash("Error loading profile data", "error")
        return redirect(url_for('home'))

    finally:
        conn.close()

@app.route('/edit_resource/<int:resource_id>', methods=['GET', 'POST'])
def edit_resource(resource_id):
    conn = get_db_connection()
    
    # Fetch the resource details to display in the form
    resource = conn.execute('SELECT * FROM resources WHERE resource_id = ?', (resource_id,)).fetchone()
    
    if not resource:
        return redirect(url_for('profile'))  # Redirect if resource not found

    # If the form is submitted
    if request.method == 'POST':
        title = request.form['title']
        description = request.form['description']
        category = request.form['category']
        availability = request.form['availability']  # Get the updated availability

        conn.execute(''' 
            UPDATE resources
            SET title = ?, description = ?, category = ?, availability = ?
            WHERE resource_id = ?
        ''', (title, description, category, availability, resource_id))
        
        conn.commit()
        conn.close()

        return redirect(url_for('profile'))  # Redirect to profile after update

    conn.close()
    return render_template('edit_resource.html', resource=resource)



# Log out route
@app.route('/logout')
def logout():
    session.clear()  # Clear session data
    flash("You have been logged out.", "info")
    return redirect(url_for('first_page'))  # Redirect to first page after logout

# Sign-up page (for new users)
from flask import render_template, request, redirect, url_for, session
from werkzeug.security import generate_password_hash
import sqlite3

@app.route('/sign_up', methods=['GET', 'POST'])
def sign_up_page():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        password = request.form['password']
        location = request.form.get('location', 'San Francisco, CA')
        
        # Handle the profile image upload
        profile_image = request.files.get('profile_image')
        profile_image_data = None
        profile_image_type = None
        
        if profile_image and profile_image.filename:
            # Read the image file
            profile_image_data = profile_image.read()
            profile_image_type = profile_image.content_type

        # Hash the password
        hashed_password = generate_password_hash(password)

        conn = get_db_connection()
        try:
            # Check if email already exists
            existing_user = conn.execute("SELECT * FROM users WHERE email = ?", (email,)).fetchone()
            
            if existing_user:
                flash("Email already registered", "error")
                return render_template('sign_up_page.html')

            # Insert user with image data
            cursor = conn.execute('''
                INSERT INTO users (name, email, password, profile_image, profile_image_type, location)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (name, email, hashed_password, profile_image_data, profile_image_type, location))
            
            conn.commit()
            flash("Registration successful!", "success")
            return redirect(url_for('log_in_page'))

        except sqlite3.Error as e:
            print(f"Database error: {e}")
            flash("Error during registration", "error")
            return render_template('sign_up_page.html')
        finally:
            conn.close()

    return render_template('sign_up_page.html')


# Route for Deleting a Resource from Rent Resources
@app.route('/delete_rent_resource', methods=['POST'])
def delete_rent_resource():
    if 'user_id' not in session:
        flash("You must be logged in to delete a resource.", "danger")
        return redirect(url_for('first_page'))  # Redirect to first page if not logged in

    resource_id = request.form.get('resource_id')  # Get the resource ID from the form

    if resource_id:
        conn = get_db_connection()
        # Delete resource where the user is the owner of the resource (user_id matches session)
        conn.execute('DELETE FROM resources WHERE id = ? AND user_id = ?', (resource_id, session['user_id']))
        conn.commit()
        conn.close()
        
        flash("Resource deleted successfully.", "success")
    else:
        flash("Resource not found.", "danger")

    return redirect(url_for('rent_resources'))  # Redirect back to rent resources page after deletion


#Route to delete resource 
@app.route('/delete_resource/<int:resource_id>', methods=['GET', 'POST'])
def delete_resource(resource_id):
    # Connect to the database
    conn = sqlite3.connect('app.db')
    cursor = conn.cursor()

    # Fetch the resource to display details (don't allow editing)
    cursor.execute("SELECT * FROM resources WHERE resource_id = ?", (resource_id,))
    resource = cursor.fetchone()

    if request.method == 'POST':
        # Delete the resource from the database
        cursor.execute("DELETE FROM resources WHERE resource_id = ?", (resource_id,))
        conn.commit()
        conn.close()

        # Redirect back to the profile page after deleting
        return redirect(url_for('profile'))

    conn.close()

    # Display the delete resource page with the resource details
    return render_template('delete_resource.html', resource=resource)

#Route to view resources from html page
@app.route('/view_resource/<int:resource_id>', methods=['GET'])
def view_resource(resource_id):
    if 'user_id' not in session:
        return redirect(url_for('log_in_page'))

    conn = get_db_connection()
    try:
        # Fetch the resource details with all necessary fields
        resource = conn.execute('''
            SELECT 
                resource_id,
                user_id,
                title,
                description,
                category,
                availability,
                date_posted,
                image,
                image_type
            FROM resources 
            WHERE resource_id = ?
        ''', (resource_id,)).fetchone()

        if not resource:
            flash("Resource not found", "error")
            return redirect(url_for('rent_resources'))

        # Fetch messages related to this resource
        messages = conn.execute(''' 
            SELECT m.*, u.name AS sender_name 
            FROM messages m 
            JOIN users u ON m.sender_id = u.user_id 
            WHERE (m.sender_id = ? OR m.receiver_id = ?) 
                AND m.thread_id = ? 
            ORDER BY m.timestamp ASC
        ''', (session['user_id'], session['user_id'], resource_id)).fetchall()

        return render_template('view_resource.html', 
                             resource=resource, 
                             messages=messages)

    except sqlite3.Error as e:
        print(f"Database error: {e}")
        flash("Error loading resource", "error")
        return redirect(url_for('rent_resources'))

    finally:
        conn.close()


@app.route('/leaser_reviews/<int:leaser_id>/<int:resource_id>', methods=['GET', 'POST'])
def leaser_reviews(leaser_id, resource_id):
    if 'user_id' not in session:
        return redirect(url_for('log_in_page'))

    conn = get_db_connection()
    try:
        # Fetch leaser data including profile image
        leaser = conn.execute('''
            SELECT 
                user_id, name, email, profile_image, profile_image_type, location
            FROM users 
            WHERE user_id = ?
        ''', (leaser_id,)).fetchone()
        
        if not leaser:
            flash('Leaser not found', 'error')
            return redirect(url_for('resources'))

        # Fetch existing reviews with reviewer information
        reviews = conn.execute(''' 
            SELECT 
                r.rating, 
                r.comment, 
                r.timestamp,
                r.reviewer_id,
                u.name,
                u.profile_image,
                u.profile_image_type
            FROM reviews r
            JOIN users u ON r.reviewer_id = u.user_id
            WHERE r.user_id = ? 
            AND r.resource_id = ?
            ORDER BY r.timestamp DESC
        ''', (leaser_id, resource_id)).fetchall()
        
        print(f"Found {len(reviews)} reviews for leaser_id: {leaser_id}, resource_id: {resource_id}")

        return render_template('leaser_reviews.html',
                             leaser=leaser,
                             reviews=reviews,
                             resource_id=resource_id,
                             current_user_id=session.get('user_id'))

    except sqlite3.Error as e:
        print(f"Database error: {e}")
        flash('Error loading reviews', 'error')
        return redirect(url_for('resources'))

    finally:
        conn.close()

@app.route('/reserve_resource/<int:resource_id>', methods=['GET', 'POST'])
def reserve_resource(resource_id):
    if 'user_id' not in session:
        return redirect(url_for('log_in_page'))

    conn = get_db_connection()
    try:
        # Fetch the resource from the database
        resource = conn.execute('''
            SELECT 
                resource_id,
                title,
                description,
                category,
                availability,
                image,
                image_type,
                user_id
            FROM resources 
            WHERE resource_id = ?
        ''', (resource_id,)).fetchone()

        if not resource:
            flash('Resource not found', 'error')
            return redirect(url_for('resources'))

        # Check if the resource is available
        if resource['availability'] != 'available':
            flash('This resource is not available for reservation', 'error')
            return redirect(url_for('resources'))

        if request.method == 'POST':
            start_date = request.form['start_date']
            end_date = request.form['end_date']
            user_id = session['user_id']

            # Insert the reservation
            conn.execute('''
                INSERT INTO reservations (
                    user_id, resource_id, start_date, end_date, active
                ) VALUES (?, ?, ?, ?, 1)
            ''', (user_id, resource_id, start_date, end_date))

            # Update resource availability
            conn.execute('''
                UPDATE resources
                SET availability = "not available"
                WHERE resource_id = ?
            ''', (resource_id,))

            conn.commit()
            flash('Resource reserved successfully!', 'success')
            return redirect(url_for('reservation_confirmation'))

        # GET request - show the reservation form
        return render_template('reserve_resource.html', resource=resource)

    except sqlite3.Error as e:
        print(f"Database error: {e}")
        flash('Error making reservation. Please try again.', 'error')
        return redirect(url_for('resources'))
    
    finally:
        conn.close()


@app.route('/reservation_confirmation')
def reservation_confirmation():
    return render_template('confirmation.html')


@app.route('/create_review/<int:resource_id>/<int:leaser_id>', methods=['GET', 'POST'])
def create_review(resource_id, leaser_id):
    if 'user_id' not in session:
        return redirect(url_for('log_in_page'))

    conn = get_db_connection()
    try:
        # Get the leaser and resource details
        leaser = conn.execute('''
            SELECT user_id, name, profile_image, profile_image_type
            FROM users 
            WHERE user_id = ?
        ''', (leaser_id,)).fetchone()
        
        resource = conn.execute('''
            SELECT resource_id, title, description
            FROM resources 
            WHERE resource_id = ?
        ''', (resource_id,)).fetchone()

        if not leaser or not resource:
            flash('Invalid leaser or resource.', 'error')
            return redirect(url_for('resources'))

        if request.method == 'POST':
            rating = request.form['rating']
            comment = request.form['comment']
            reviewer_id = session['user_id']
            timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

            conn.execute('''
                INSERT INTO reviews (user_id, reviewer_id, resource_id, rating, comment, timestamp)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (leaser_id, reviewer_id, resource_id, rating, comment, timestamp))

            conn.commit()
            flash('Review posted successfully!', 'success')
            return redirect(url_for('leaser_reviews', leaser_id=leaser_id, resource_id=resource_id))

        return render_template('create_review.html', 
                             leaser=leaser, 
                             resource=resource)

    except sqlite3.Error as e:
        print(f"Database error: {e}")
        flash('Error posting review. Please try again.', 'error')
        return redirect(url_for('leaser_reviews', leaser_id=leaser_id, resource_id=resource_id))
    
    finally:
        conn.close()

@app.route('/edit_availability/<int:reservation_id>', methods=['GET', 'POST'])
def edit_availability(reservation_id):
    if 'user_id' not in session:
        return redirect(url_for('log_in_page')) 

    conn = get_db_connection()

    # Fetch the resource related to the reservation
    reservation = conn.execute('''
        SELECT r.*, res.title, res.availability
        FROM reservations r
        JOIN resources res ON r.resource_id = res.resource_id
        WHERE r.reservation_id = ? AND r.user_id = ?
    ''', (reservation_id, session['user_id'])).fetchone()

    if not reservation:
        conn.close()
        return redirect(url_for('profile'))  # If no such reservation, redirect back

    if request.method == 'POST':
        availability = request.form['availability']

        # Update the availability of the resource
        conn.execute('''
            UPDATE resources
            SET availability = ?
            WHERE resource_id = ?
        ''', (availability, reservation['resource_id']))
        
        conn.commit()
        conn.close()

        return redirect(url_for('profile'))  # After updating, return to the profile page

    conn.close()

    return render_template('edit_availability.html', resource=reservation, reservation_id=reservation_id)

@app.route('/mark_not_active/<int:reservation_id>', methods=['POST'])
def mark_not_active(reservation_id):
    conn = get_db_connection()

    # Fetch the reservation by ID
    reservation = conn.execute('SELECT * FROM reservations WHERE reservation_id = ?', (reservation_id,)).fetchone()

    if not reservation:
        return redirect(url_for('profile'))  # If reservation doesn't exist, redirect to profile

    # Set the reservation as not active (active = 0)
    conn.execute('UPDATE reservations SET active = 0 WHERE reservation_id = ?', (reservation_id,))

    # Set the resource's availability to "available" (lowercase)
    conn.execute('UPDATE resources SET availability = "available" WHERE resource_id = ?', (reservation['resource_id'],))

    # Commit the changes
    conn.commit()
    conn.close()

    # Redirect back to the profile page
    return redirect(url_for('profile'))


@app.route('/mark_available/<int:resource_id>', methods=['POST'])
def mark_available(resource_id):
    conn = get_db_connection()

    # Fetch the resource from the database
    resource = conn.execute('SELECT * FROM resources WHERE resource_id = ?', (resource_id,)).fetchone()

    if not resource:
        return redirect(url_for('resources'))  # If resource doesn't exist, redirect to resources page

    # Check if the resource is already available
    if resource['availability'] == 'available':
        return redirect(url_for('profile'))  # If it's already available, do nothing

    # Mark the resource as available (lowercase 'available')
    conn.execute('UPDATE resources SET availability = "available" WHERE resource_id = ?', (resource_id,))

    # Find all active reservations for this resource
    active_reservations = conn.execute(''' 
        SELECT * FROM reservations 
        WHERE resource_id = ? AND active = 1
    ''', (resource_id,)).fetchall()

    # If there are active reservations, set them as inactive (active = 0)
    if active_reservations:
        for reservation in active_reservations:
            conn.execute('UPDATE reservations SET active = 0 WHERE reservation_id = ?', (reservation['reservation_id'],))

    # Commit the changes to the database
    conn.commit()
    conn.close()

    # Redirect back to the profile page
    return redirect(url_for('profile'))

@app.route('/mark_unavailable/<int:resource_id>', methods=['POST'])
def mark_unavailable(resource_id):
    conn = get_db_connection()

    # Fetch the resource from the database
    resource = conn.execute('SELECT * FROM resources WHERE resource_id = ?', (resource_id,)).fetchone()

    if not resource:
        return redirect(url_for('resources'))  # If resource doesn't exist, redirect to resources page

    # Check if the resource is already unavailable
    if resource['availability'] == 'not available':
        return redirect(url_for('profile'))  # If it's already unavailable, do nothing

    # Mark the resource as unavailable (uppercase 'Not Available')
    conn.execute('UPDATE resources SET availability = "not available" WHERE resource_id = ?', (resource_id,))

    # Commit the changes to the database
    conn.commit()
    conn.close()

    # Redirect back to the profile page
    return redirect(url_for('profile'))

@app.route('/conversation/<int:thread_id>', methods=['GET', 'POST'])
def view_conversation(thread_id):
    if 'user_id' not in session:
        return redirect(url_for('log_in_page'))

    conn = get_db_connection()

    # Query to get messages by thread_id
    messages = conn.execute("""
        SELECT m.*, u.name AS sender_name, u2.name AS receiver_name
        FROM messages m
        JOIN users u ON m.sender_id = u.user_id
        JOIN users u2 ON m.receiver_id = u2.user_id
        WHERE m.thread_id = ?
        ORDER BY m.timestamp ASC
    """, (thread_id,)).fetchall()

    # Get the other user details
    other_user = None
    if messages:
        # Pick the first message's sender/receiver as the other user
        first_message = messages[0]
        other_user_id = first_message['sender_id'] if first_message['receiver_id'] == session['user_id'] else first_message['receiver_id']
        other_user = conn.execute('SELECT name FROM users WHERE user_id = ?', (other_user_id,)).fetchone()

    # Handle the form submission for sending a new message
    if request.method == 'POST':
        content = request.form['content']  # Get message content from the form
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')  # Corrected timestamp usage

        # Insert the new message into the database
        conn.execute('''
            INSERT INTO messages (sender_id, receiver_id, content, timestamp, thread_id) 
            VALUES (?, ?, ?, ?, ?)
        ''', (session['user_id'], other_user_id, content, timestamp, thread_id))

        conn.commit()
        conn.close()

        return redirect(url_for('view_conversation', thread_id=thread_id))  # Redirect back to the conversation view after sending the message

    conn.close()

    return render_template('view_conversation.html', messages=messages, other_user=other_user, thread_id=thread_id)

@app.route('/messages', methods=['GET'])
def messages():
    if 'user_id' not in session:
        return redirect(url_for('log_in_page'))

    conn = get_db_connection()
    user_id = session['user_id']

    # Fetch distinct conversations (grouped by thread_id)
    conversations = conn.execute("""
        SELECT
            m.thread_id,
            MAX(m.timestamp) AS last_message_timestamp,
            u1.name AS sender_name,
            u2.name AS receiver_name,
            (SELECT content FROM messages WHERE thread_id = m.thread_id AND sender_id = ? ORDER BY timestamp DESC LIMIT 1) AS last_message_from_me,
            (SELECT content FROM messages WHERE thread_id = m.thread_id AND receiver_id = ? ORDER BY timestamp DESC LIMIT 1) AS last_message_to_me,
            (SELECT timestamp FROM messages WHERE thread_id = m.thread_id AND sender_id = ? ORDER BY timestamp DESC LIMIT 1) AS last_message_from_me_timestamp,
            (SELECT timestamp FROM messages WHERE thread_id = m.thread_id AND receiver_id = ? ORDER BY timestamp DESC LIMIT 1) AS last_message_to_me_timestamp
        FROM messages m
        JOIN users u1 ON m.sender_id = u1.user_id
        JOIN users u2 ON m.receiver_id = u2.user_id
        WHERE m.sender_id = ? OR m.receiver_id = ?
        GROUP BY m.thread_id
        ORDER BY last_message_timestamp DESC
    """, (user_id, user_id, user_id, user_id, user_id, user_id)).fetchall()

    conn.close()

    return render_template('messages.html', conversations=conversations)



@app.route('/check_db', methods=['GET'])
def check_db():
    conn = get_db_connection()
    try:
        # Check reviews table structure
        table_info = conn.execute("PRAGMA table_info(reviews)").fetchall()
        print("Reviews table structure:", table_info)
        
        # Check for any existing reviews
        reviews = conn.execute("SELECT * FROM reviews").fetchall()
        print("Existing reviews:", reviews)
        
        return "Check your console for database information"
    finally:
        conn.close()




@app.route('/send_message/<int:resource_id>', methods=['GET', 'POST'])
def send_message(resource_id):
    if 'user_id' not in session:
        return redirect(url_for('log_in_page')) 

    conn = get_db_connection()

    # Fetch the resource details using resource_id
    resource = conn.execute('SELECT * FROM resources WHERE resource_id = ?', (resource_id,)).fetchone()

    if not resource:
        return redirect(url_for('resources'))  # If resource not found, redirect to resources page

    # Handle the form submission for sending a message
    if request.method == 'POST':
        content = request.form['content']  # Get message content from the form
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')  # Corrected timestamp usage

        # Insert the message into the database
        conn.execute('''
            INSERT INTO messages (sender_id, receiver_id, content, timestamp, thread_id) 
            VALUES (?, ?, ?, ?, ?)
        ''', (session['user_id'], resource['user_id'], content, timestamp, resource_id))  # Assuming user_id of resource owner is in resource['user_id'])

        conn.commit()
        conn.close()

        return redirect(url_for('view_resource', resource_id=resource_id))  # Redirect back to the resource view page after sending the message

    conn.close()

    # Pass the resource data along with the resource_id to the template
    return render_template('send_message.html', resource=resource, resource_id=resource_id)



@app.route('/toggle_availability/<int:resource_id>', methods=['POST'])
def toggle_availability(resource_id):
    conn = get_db_connection()

    # Fetch the resource from the database
    resource = conn.execute('SELECT * FROM resources WHERE resource_id = ?', (resource_id,)).fetchone()

    if not resource:
        return redirect(url_for('resources'))  # If resource doesn't exist, redirect to resources page

    # Check availability in lowercase
    availability = resource['availability'].lower()  # Ensure comparison is case-insensitive

    # If the resource is available, make it unavailable
    if availability == 'available':
        conn.execute('UPDATE resources SET availability = "unavailable" WHERE resource_id = ?', (resource_id,))
        conn.commit()
        conn.close()
        return redirect(url_for('profile'))  # Redirect back to profile page

    # If the resource is unavailable and has no active reservations, make it available
    elif availability == 'unavailable':
        active_reservation = conn.execute('''
            SELECT * FROM reservations 
            WHERE resource_id = ? AND active = 1
        ''', (resource_id,)).fetchone()

        # If there are no active reservations, make the resource available
        if not active_reservation:
            conn.execute('UPDATE resources SET availability = "available" WHERE resource_id = ?', (resource_id,))
            conn.commit()
            conn.close()
            return redirect(url_for('profile'))  # Redirect back to profile page

        # If the resource is unavailable because of a reservation, mark the reservation as inactive and make the resource available
        else:
            conn.execute('UPDATE reservations SET active = 0 WHERE resource_id = ?', (resource_id,))
            conn.execute('UPDATE resources SET availability = "available" WHERE resource_id = ?', (resource_id,))
            conn.commit()
            conn.close()
            return redirect(url_for('profile'))  # Redirect back to profile page

    # Fetch the resource and its owner
    resource = conn.execute('SELECT * FROM resources WHERE resource_id = ?', (resource_id,)).fetchone()

    if not resource:
        return redirect(url_for('resources'))  # If resource not found, redirect to resources page

    # If the method is POST, the user is submitting a message
    if request.method == 'POST':
        content = request.form['content']  # The content of the message
        sender_id = session['user_id']
        receiver_id = resource['user_id']
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')  # Current timestamp

        # Insert the message into the database
        conn.execute('''
            INSERT INTO messages (sender_id, receiver_id, content, timestamp)
            VALUES (?, ?, ?, ?)
        ''', (sender_id, receiver_id, content, timestamp))

        conn.commit()
        conn.close()

        return redirect(url_for('profile'))  # Redirect back to profile after sending the message

    conn.close()
    return render_template('send_message.html', resource=resource)

    
@app.route('/inbox', methods=['GET'])
def inbox():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    conn = get_db_connection()
    user_id = session['user_id']

    # Fetch all messages where the user is either the sender or the receiver
    messages = conn.execute("""
        SELECT
            m.message_id,
            m.sender_id,
            m.receiver_id,
            m.content,
            m.timestamp,
            u1.name AS sender_name,
            u2.name AS receiver_name
        FROM messages m
        JOIN users u1 ON m.sender_id = u1.user_id
        JOIN users u2 ON m.receiver_id = u2.user_id
        WHERE m.sender_id = ? OR m.receiver_id = ?
        ORDER BY m.timestamp DESC
    """, (user_id, user_id)).fetchall()

    conn.close()

    return render_template('messages.html', messages=messages)

@app.route('/login', methods=['GET', 'POST'])
def login():
    # Your login logic here
    pass

def inbox():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    conn = get_db_connection()
    user_id = session['user_id']

    # Fetch all messages where the user is either the sender or the receiver
    messages = conn.execute("""
        SELECT
            m.message_id,
            m.sender_id,
            m.receiver_id,
            m.content,
            m.timestamp,
            u1.name AS sender_name,
            u2.name AS receiver_name
        FROM messages m
        JOIN users u1 ON m.sender_id = u1.user_id
        JOIN users u2 ON m.receiver_id = u2.user_id
        WHERE m.sender_id = ? OR m.receiver_id = ?
        ORDER BY m.timestamp DESC
    """, (user_id, user_id)).fetchall()

    conn.close()

    return render_template('messages.html', messages=messages)

if __name__ == '__main__':
    init_db()  # Initialize the database
    app.run(debug=True, host= '0.0.0.0', port = 5000)
