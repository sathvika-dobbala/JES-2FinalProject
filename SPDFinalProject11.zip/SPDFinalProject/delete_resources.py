import sqlite3

def delete_resource_and_messages(resource_id):
    # Connect to the SQLite database
    conn = sqlite3.connect('app.db')
    c = conn.cursor()

    try:
        # Step 1: Delete messages related to the resource
        c.execute('''DELETE FROM messages WHERE content LIKE ?''', (f'%Gardening Tools%',))  # or use more specific content if needed
        print(f"Messages related to resource_id {resource_id} deleted.")

        # Step 2: Delete the resource from the resources table
        c.execute('''DELETE FROM resources WHERE resource_id = ?''', (resource_id,))
        conn.commit()  # Commit the transaction

        print(f"Resource with ID {resource_id} deleted successfully.")

    except sqlite3.Error as e:
        print(f"An error occurred: {e}")
    
    finally:
        # Close the connection
        conn.close()

# Call the function with the resource_id to delete (in this case, resource_id = 17)
delete_resource_and_messages(17)
