import sqlite3
from werkzeug.security import generate_password_hash
from datetime import datetime

def init_db():
    conn = sqlite3.connect('app.db')
    c = conn.cursor()

    # Drop existing tables
    tables = ['reservations', 'users', 'resources', 'messages', 'reviews']
    for table in tables:
        c.execute(f'DROP TABLE IF EXISTS {table}')

    # Create Users Table with binary image data
    c.execute('''
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE,
            password TEXT NOT NULL,
            profile_image BLOB,           -- Changed to BLOB for binary image data
            profile_image_type TEXT,      -- Store the image MIME type
            location TEXT
        )
    ''')

    # Create Resources Table with binary image data
    c.execute('''
        CREATE TABLE IF NOT EXISTS resources (
            resource_id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            title TEXT NOT NULL,
            description TEXT,
            image BLOB,                   -- Changed to BLOB for binary image data
            image_type TEXT,              -- Store the image MIME type
            category TEXT,
            availability TEXT DEFAULT 'available',
            date_posted TEXT NOT NULL,
            FOREIGN KEY(user_id) REFERENCES users(user_id)
        )
    ''')

    # Create Reservations Table
    c.execute('''
        CREATE TABLE IF NOT EXISTS reservations (
            reservation_id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            resource_id INTEGER,
            start_date DATETIME NOT NULL,
            end_date DATETIME NOT NULL,
            active INTEGER DEFAULT 1,
            FOREIGN KEY(user_id) REFERENCES users(user_id),
            FOREIGN KEY(resource_id) REFERENCES resources(resource_id)
        )
    ''')

    # Create Messages Table
    c.execute('''
        CREATE TABLE IF NOT EXISTS messages (
            message_id INTEGER PRIMARY KEY AUTOINCREMENT,
            sender_id INTEGER,
            receiver_id INTEGER,
            content TEXT NOT NULL,
            timestamp TEXT NOT NULL,
            thread_id INTEGER,
            FOREIGN KEY(sender_id) REFERENCES users(user_id),
            FOREIGN KEY(receiver_id) REFERENCES users(user_id)
        )
    ''')

    # Create Reviews Table
    c.execute('''
        CREATE TABLE IF NOT EXISTS reviews (
            review_id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            reviewer_id INTEGER,
            resource_id INTEGER,
            rating INTEGER NOT NULL,
            comment TEXT,
            timestamp TEXT NOT NULL,
            FOREIGN KEY(user_id) REFERENCES users(user_id),
            FOREIGN KEY(reviewer_id) REFERENCES users(user_id),
            FOREIGN KEY(resource_id) REFERENCES resources(resource_id)
        )
    ''')

    # Example data will be added through the UI now since we're handling binary image data
    conn.commit()
    conn.close()
    print("Database initialized successfully with updated schema for image handling!")

if __name__ == '__main__':
    init_db()